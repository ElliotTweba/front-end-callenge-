import React from 'react';
import './styles.css'
import user from "./user.png";
import ar from "./arr.png";

function Form() {
    return(
    <div className="form">

      <div className="column right">
      <img className='user' src={user} alt="react logo" /><br />      
      <h2>Front-end Challenge!</h2>
      <p> This is a Desin tat you will need to code up and impress us</p>
      <img className='arrow' src={ar} alt="react logo" />
  </div>
  <div className="column left">
        <div>
        <label className="form__label" for="Name"></label>
        </div>
        <div>
        <label className="form__lable" for="gender"></label>
        </div>
        <div>
        <label className="form__lable" for="date"></label>
        </div>
        <div>
        <label className="form__label" for="email"> </label>
        </div>
        <div>
        <label className="form__lable" for="mobile"> </label>
        </div>
        <div>
        <label className="form__label" for="id"></label>
        </div>
        <div>
        <label className="form__lable" for="membersip"></label>
        </div>
  </div>

      <div className="column middle">
        <div className="Name">
        <label className="form__label" for="Name">Name </label>        
        <input type="text" className="form_input" />
        </div>
        <div> 
        <label className="form__label" for="gender">Gender </label>
        <input type="radio" value="Male" name="gender" className="radio" />Male
        <input type="radio" value="Female" name="gender" className="radio" />Female
        </div>
        <div>
        <label className="form__label" for="date">Date </label>
        <input type="date" className="form_input" />
        </div>
        <div className="email">
        <label className="form__label" for="email">Email </label>
        <input type="email" className="form_input" />
        </div>
        <div className="Mobile">
        <label className="form__label" for="mobile">Mobile </label>
        <input type="text" className="form_input" />
        </div>
        <div className="ID">
        <label className="form__label" for="id">Customer ID </label>
        <input type="text" className="form_input" />
        </div>
        <div> 
        <input type="radio" value="Classic" name="membership" className="radio" /> Classic
        <input type="radio" value="Silver" name="membership" className="radio" /> Silver
        <input type="radio" value="Gold" name="membership" className="radio" /> Gold
        </div>
        <div class="footer">
              <button type="submit" class="btn">CANCEL</button>
              <button type="submit" class="btn">SAVE</button>
        </div>
      </div>               
      </div>
      )       
    }
    export default Form;